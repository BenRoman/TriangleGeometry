## Mesh Explorer Screenshots

![](Screenshots_shot-1.png)
_Mesh Explorer after loading superior.poly with_ Mesh Control _tab active._


![](Screenshots_shot-2.png)
_Showing quality mesh of Lake Superior  with_ Statistic _tab active._


![](Screenshots_shot-3.png)
_Showing mesh and bounded Voronoi diagram with_ About _tab active._

